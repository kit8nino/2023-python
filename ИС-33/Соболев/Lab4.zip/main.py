import turtle

from Avatar import Avatar
from Mob import Mob


def readMaze():
    maze = []

    # Открываем файл с лабиринтом и считываем его в матрицу
    with open("maze-for-u.txt", "r") as f:
        file = f.readlines()

        height = len(file)
        width = len(file[0]) - 1

        for line in file:
            tmp_line = [0 if sym == "#" else 1 for sym in line[:-1]]
            maze.append(tmp_line[:])

    return maze, height, width


def main():
    maze, height, width = readMaze()

    turtle.setup(1800, 1000)

    maze_turtle = turtle.Turtle()
    maze_turtle.shape('square')
    maze_turtle.color('black')
    maze_turtle.shapesize(0.1)
    maze_turtle.penup()
    maze_turtle.speed(100)

    for y in range(height):
        for x in range(width):
            if maze[y][x] == 0:
                maze_turtle.goto(x * 2 - 800, -y * 2 + 495)
                maze_turtle.stamp()

    '''
    # Ввод исходных данных
    print(f"Координаты аватара через пробел: ", end="")
    avatar_pos = tuple([int(_) for _ in input().split()])
    print(f"\nКоординаты ключа через пробел: ", end="")
    key_pos = tuple([int(_) for _ in input().split()])
    print(f"\nКоординаты выхода через пробел: ", end="")
    exit_pos = tuple([int(_) for _ in input().split()])
    '''

    print("Координаты аватара через пробел: 0 1")
    print("Координаты моба через пробел: 466 592")
    print("Координаты выхода через пробел: 599 798")

    """
    Данные для test-maze.txt
    avatar_pos = 0, 1
    mob_pos = 98, 1 
    exit_pos = 99, 98
    """

    avatar_pos = 0, 1
    mob_pos = 466, 592
    exit_pos = 599, 798

    avatar = Avatar(avatar_pos, 10)
    mob = Mob(mob_pos, 10)

    while True:
        avatar.move(maze, height, width, exit_pos)
        if avatar.getPosition() == mob.getPosition() or avatar.getPosition() == exit_pos:
            break

        mob.move(maze, height, width, avatar.getPosition())
        if avatar.getPosition() == mob.getPosition():
            break


if __name__ == "__main__":
    main()
